import { readFile, writeFile } from 'node:fs/promises'
import { resolve, normalize } from 'node:path'
import { fileURLToPath } from 'node:url'
import type { Plugin } from 'vite'
import { fingerprintMatrix, KEYLINE_CLASS_RE, matrixNameForKeyboard, round2, SIZE_CLASS_RE, stripLegacySizeClasses } from './alignShared.ts'

/**
 * 本地按键对齐工具（仅 npm run dev）
 * 主工程只需在 vite.config 里「文件存在则加载」本插件；不要改 App.vue。
 * 负责：注入面板 + 写回 keyStore / key.vue
 */
export const RK_ALIGN_PLUGIN_VERSION = 8

type AlignKeyPatch = {
  index: number
  position?: number
  offset: number
  offsetY?: number
  style?: string
  width?: number
  height?: number
}

export function rkAlignWritePlugin(): Plugin {
  const root = fileURLToPath(new URL('../..', import.meta.url))
  const mountPath = fileURLToPath(new URL('./mount.ts', import.meta.url)).replace(/\\/g, '/')
  const VIRTUAL_ID = 'virtual:rk-key-align'
  const RESOLVED_VIRTUAL_ID = '\0' + VIRTUAL_ID
  const num = '-?\\d+(?:\\.\\d+)?'
  const fmt = (n: number) => String(round2(n))

  const assertSafePath = (rel: string, kind: 'store' | 'vue') => {
    const n = normalize(rel).replace(/\\/g, '/')
    if (n.includes('..')) throw new Error(`非法路径: ${rel}`)
    if (kind === 'store' && (!n.startsWith('src/stores/') || !n.endsWith('keyStore.ts'))) {
      throw new Error(`storePath 必须在 src/stores/**/keyStore.ts: ${rel}`)
    }
    if (kind === 'vue' && (!n.startsWith('src/components/') || !n.endsWith('/key.vue'))) {
      throw new Error(`vuePath 必须在 src/components/**/key.vue: ${rel}`)
    }
    return resolve(root, n)
  }

  const extractGetIndex = (src: string): ((l: number, c: number) => number) => {
    const compile = (p1: string, p2: string, expr: string) => {
      try {
        const fn = new Function(p1, p2, `"use strict"; return (${expr});`) as (
          a: number,
          b: number
        ) => number
        const sample = fn(1, 2)
        if (!Number.isFinite(sample)) return null
        return (l: number, c: number) => Number(fn(l, c))
      } catch {
        return null
      }
    }

    const block = src.match(
      /const getIndex\s*=\s*\(\s*(\w+)[^,)]*,\s*(\w+)[^)]*\)\s*(?::[^=\{]+)?\s*=>\s*\{([\s\S]*?)\}/
    )
    if (block) {
      const ret = block[3].match(/return\s+([^;]+)/)
      const fn = ret ? compile(block[1], block[2], ret[1]) : null
      if (fn) return fn
    }

    const arrow = src.match(
      /const getIndex\s*=\s*\(\s*(\w+)[^,)]*,\s*(\w+)[^)]*\)\s*(?::[^=\{]+)?\s*=>\s*([^;\{]+)/
    )
    if (arrow) {
      const fn = compile(arrow[1], arrow[2], arrow[3])
      if (fn) return fn
    }

    if (/\bgetIndex\s*\(/.test(src) && /\bconst\s+getIndex\b/.test(src)) {
      throw new Error('无法解析 getIndex（星闪是 row * 列数 + col），拒绝写入以免改错键')
    }
    return (l, c) => {
      throw new Error(`文件没有可用的 getIndex，无法处理 getIndex(${l}, ${c})`)
    }
  }

  const findMatchingBracket = (src: string, start: number) => {
    let depth = 0
    let quote: string | null = null
    for (let i = start; i < src.length; i++) {
      const ch = src[i]
      if (quote) {
        if (ch === '\\') {
          i++
          continue
        }
        if (ch === quote) quote = null
        continue
      }
      if (ch === '"' || ch === "'" || ch === '`') {
        quote = ch
        continue
      }
      if (ch === '[') depth++
      else if (ch === ']') {
        depth--
        if (depth === 0) return i + 1
      }
    }
    return -1
  }

  const matrixBlocks = (src: string) => {
    const blocks: Array<{ name: string; start: number; end: number; body: string }> = []
    const re = /const (keyMatrix_\w+)\s*=\s*\[/g
    let m: RegExpExecArray | null
    while ((m = re.exec(src))) {
      const bracket = src.indexOf('[', m.index)
      const end = findMatchingBracket(src, bracket)
      if (end > bracket) {
        blocks.push({ name: m[1], start: m.index, end, body: src.slice(m.index, end) })
      }
    }
    return blocks
  }

  const lineCommented = (src: string, at: number) => {
    const lineStart = src.lastIndexOf('\n', Math.max(0, at - 1)) + 1
    return src.slice(lineStart, at).includes('//')
  }

  const pickMatrixBlock = (
    src: string,
    getIndex: (l: number, c: number) => number,
    opts: { keyboardNames?: string[]; layoutFingerprint?: string }
  ) => {
    const blocks = matrixBlocks(src)
    if (!blocks.length) {
      if (/\bkeyMatrix_\w+/.test(src)) {
        throw new Error('无法切分 keyMatrix_*，拒绝整文件替换')
      }
      return null
    }
    if (blocks.length === 1) return blocks[0]

    const wanted = matrixNameForKeyboard(src, opts.keyboardNames)
    const byName = wanted ? blocks.find((b) => b.name === wanted) : undefined

    const live = opts.layoutFingerprint || ''
    const scored = live
      ? blocks
          .map((b) => ({ b, score: fingerprintMatrix(b.body, getIndex) === live ? 1 : 0 }))
          .filter((x) => x.score)
      : []

    if (byName && scored.length) {
      const hit = scored.find((x) => x.b.name === byName.name)
      if (hit) return hit.b
      throw new Error(
        `键盘名对应 ${byName.name}，但当前页面键位对上的是 ${scored.map((x) => x.b.name).join('/')}`
      )
    }
    if (byName) return byName
    if (scored.length === 1) return scored[0].b
    if (scored.length > 1) {
      throw new Error(
        `当前页面键位同时匹配 ${scored.map((x) => x.b.name).join('/')}，无法判断语言。请确认设备名已写在 keyboardDefine.name 里`
      )
    }
    throw new Error(
      `无法确定当前语言的 keyMatrix（候选 ${blocks.map((b) => b.name).join('/')}）。请重启 npm run dev 后再试`
    )
  }

  const patchKeyStoreChunk = (
    src: string,
    keys: AlignKeyPatch[],
    getIndex: (l: number, c: number) => number
  ) => {
    const byIndex = new Map(keys.map((k) => [k.index, k]))
    const matchKey = (idx: number, pos: string) => {
      const k = byIndex.get(idx)
      if (!k) return null
      if (k.position != null && Number(pos) !== Number(k.position)) return null
      return k
    }
    const reGetIndex = new RegExp(
      `index:\\s*getIndex\\((\\d+),\\s*(\\d+)\\),\\s*keyData:\\s*getKeyData\\(getIndex\\(\\1,\\s*\\2\\)\\),\\s*position:\\s*(${num}),\\s*offset:\\s*(${num})(?:,\\s*offsetY:\\s*(${num}))?`,
      'g'
    )
    let out = src.replace(reGetIndex, (full, ...rest: Array<string | number>) => {
      const all = String(rest[rest.length - 1])
      const at = Number(rest[rest.length - 2])
      if (lineCommented(all, at)) return full
      const l = String(rest[0])
      const c = String(rest[1])
      const pos = String(rest[2])
      const k = matchKey(getIndex(Number(l), Number(c)), pos)
      if (!k) return full
      const oy = round2(k.offsetY || 0)
      const oyPart = oy !== 0 ? `, offsetY: ${fmt(oy)}` : ''
      return `index: getIndex(${l}, ${c}), keyData: getKeyData(getIndex(${l}, ${c})), position: ${pos}, offset: ${fmt(k.offset)}${oyPart}`
    })

    const reRaw = new RegExp(
      `(index:\\s*)(\\d+)(,\\s*keyData:[^\\n]*?position:\\s*(${num}),\\s*offset:\\s*)(${num})(?:,\\s*offsetY:\\s*${num})?`,
      'g'
    )
    out = out.replace(reRaw, (full, ...rest: Array<string | number>) => {
      const all = String(rest[rest.length - 1])
      const at = Number(rest[rest.length - 2])
      if (lineCommented(all, at)) return full
      const p1 = String(rest[0])
      const indexStr = String(rest[1])
      const mid = String(rest[2])
      const pos = String(rest[3])
      const k = matchKey(Number(indexStr), pos)
      if (!k) return full
      // 保留原来的 index 写法。巨鹏是字面量 index: 34，不能改成 getIndex(行, 列)
      const oy = round2(k.offsetY || 0)
      const oyPart = oy !== 0 ? `, offsetY: ${fmt(oy)}` : ''
      return `${p1}${indexStr}${mid}${fmt(k.offset)}${oyPart}`
    })

    const reStyleGetIndex = new RegExp(
      `(style:\\s*)(['"])([^'"]*)(\\2)(,\\s*index:\\s*getIndex\\()(\\d+)(,\\s*)(\\d+)(\\))`,
      'g'
    )
    out = out.replace(reStyleGetIndex, (full, ...rest: Array<string | number>) => {
      const all = String(rest[rest.length - 1])
      const at = Number(rest[rest.length - 2])
      if (lineCommented(all, at)) return full
      const p1 = String(rest[0])
      const q = String(rest[1])
      const style = String(rest[2])
      const p5 = String(rest[4])
      const l = String(rest[5])
      const p7 = String(rest[6])
      const c = String(rest[7])
      const p9 = String(rest[8])
      const idx = getIndex(Number(l), Number(c))
      const k = byIndex.get(idx)
      if (!k?.style || k.style === style) return full
      const nextStyle = stripLegacySizeClasses(k.style)
      if (!nextStyle || nextStyle === style) return full
      return `${p1}${q}${nextStyle}${q}${p5}${l}${p7}${c}${p9}`
    })
    const reStyleRaw = new RegExp(
      `(style:\\s*)(['"])([^'"]*)(\\2)(,\\s*index:\\s*)(\\d+)`,
      'g'
    )
    out = out.replace(reStyleRaw, (full, ...rest: Array<string | number>) => {
      const all = String(rest[rest.length - 1])
      const at = Number(rest[rest.length - 2])
      if (lineCommented(all, at)) return full
      const p1 = String(rest[0])
      const q = String(rest[1])
      const style = String(rest[2])
      const p5 = String(rest[4])
      const indexStr = String(rest[5])
      const k = byIndex.get(Number(indexStr))
      if (!k?.style || k.style === style) return full
      const nextStyle = stripLegacySizeClasses(k.style)
      if (!nextStyle || nextStyle === style) return full
      return `${p1}${q}${nextStyle}${q}${p5}${indexStr}`
    })
    return out
  }

  const patchKeyStore = (
    src: string,
    keys: AlignKeyPatch[],
    opts: { keyboardNames?: string[]; layoutFingerprint?: string }
  ) => {
    const getIndex = extractGetIndex(src)
    const target = pickMatrixBlock(src, getIndex, opts)
    if (!target) {
      return { src: patchKeyStoreChunk(src, keys, getIndex), matrixName: '' }
    }
    const next = patchKeyStoreChunk(target.body, keys, getIndex)
    if (keys.length && next === target.body) {
      throw new Error(`在 ${target.name} 里没有匹配到要改的键，已取消写入`)
    }
    return {
      src: src.slice(0, target.start) + next + src.slice(target.end),
      matrixName: target.name,
    }
  }

  /**
   * 改 width/height；兼容 .key 内嵌套 img{}（只改到第一个 } 之前的属性）
   * className 可为 key 或 key_xxx
   */
  const upsertCssDecls = (src: string, className: string, decls: Record<string, string>) => {
    if (!/^key(?:[_a-z0-9]+)?$/i.test(className) && !KEYLINE_CLASS_RE.test(className)) return src
    let out = src
    const hasBlock = new RegExp(`\\.${className}\\b[^{]*\\{`).test(out)
    for (const [prop, val] of Object.entries(decls)) {
      const propRe = new RegExp(`(\\.${className}\\b[^{]*\\{[^}]*?${prop}:\\s*)([^;\\n]+)`)
      if (propRe.test(out)) {
        out = out.replace(propRe, `$1${val}`)
        continue
      }
      if (hasBlock) {
        out = out.replace(new RegExp(`(\\.${className}\\b[^{]*\\{)`), `$1\n    ${prop}: ${val};`)
        continue
      }
      const block = `\n.${className} {\n    ${prop}: ${val};\n}\n`
      out = /<\/style>/i.test(out) ? out.replace(/<\/style>/i, `${block}</style>`) : out + block
    }
    return out
  }

  return {
    name: 'rk-align-write',
    apply: 'serve',
    resolveId(id) {
      if (id === VIRTUAL_ID) return RESOLVED_VIRTUAL_ID
    },
    load(id) {
      if (id !== RESOLVED_VIRTUAL_ID) return
      return `export { mountAlignTool } from ${JSON.stringify(mountPath)}\n`
    },
    transform(code, id) {
      const cleanId = id.split('?')[0].replace(/\\/g, '/')
      if (!/\/src\/main\.(ts|js|tsx|jsx)$/.test(cleanId)) return
      if (code.includes(VIRTUAL_ID) || code.includes('mountAlignTool')) return
      return {
        code: `${code}\n;import(${JSON.stringify(VIRTUAL_ID)}).then((m) => m.mountAlignTool());\n`,
        map: null,
      }
    },
    configureServer(server) {
      server.middlewares.use('/__rk_align_write', async (req, res, next) => {
        if (req.method === 'GET') {
          res.statusCode = 200
          res.setHeader('Content-Type', 'application/json')
          res.end(JSON.stringify({ ok: true, pluginVersion: RK_ALIGN_PLUGIN_VERSION }))
          return
        }
        if (req.method !== 'POST') {
          next()
          return
        }
        try {
          const chunks: Buffer[] = []
          for await (const chunk of req) chunks.push(Buffer.from(chunk))
          const body = JSON.parse(Buffer.concat(chunks).toString('utf-8') || '{}') as {
            storePath?: string
            vuePath?: string
            keys?: AlignKeyPatch[]
            keyboardName?: string
            keyboardNames?: string[]
            layoutFingerprint?: string
            widths?: Record<string, number>
            heights?: Record<string, number>
            keylineTops?: Record<string, number>
            keylineLefts?: Record<string, number>
            pluginVersion?: number
          }

          if (body.pluginVersion != null && body.pluginVersion !== RK_ALIGN_PLUGIN_VERSION) {
            throw new Error('对齐写入插件未更新，请完全停止后重新运行 npm run dev')
          }
          if (!body.storePath) throw new Error('缺少 storePath')
          const storeAbs = assertSafePath(body.storePath, 'store')
          const keys = body.keys || []
          const keyboardNames = [
            ...(body.keyboardNames || []),
            ...(body.keyboardName ? [body.keyboardName] : []),
          ]

          let matrixName = ''
          if (keys.length) {
            const keyStore = await readFile(storeAbs, 'utf-8')
            const patched = patchKeyStore(keyStore, keys, {
              keyboardNames,
              layoutFingerprint: body.layoutFingerprint,
            })
            matrixName = patched.matrixName
            await writeFile(storeAbs, patched.src, 'utf-8')
          }

          let sizeCount = 0
          if (body.vuePath) {
            const vueAbs = assertSafePath(body.vuePath, 'vue')
            const keyVueOriginal = await readFile(vueAbs, 'utf-8')
            let keyVue = keyVueOriginal
            const widths = { ...(body.widths || {}) }
            const heights = { ...(body.heights || {}) }

            for (const key of keys) {
              if (!key.style) continue
              const m = stripLegacySizeClasses(key.style).split(/\s+/).find((c) => SIZE_CLASS_RE.test(c))
              if (!m) continue
              if (key.width != null) widths[m] = key.width
              if (key.height != null) heights[m] = key.height
            }

            const classNames = new Set([...Object.keys(widths), ...Object.keys(heights)])
            for (const cls of classNames) {
              const decls: Record<string, string> = {}
              if (widths[cls] != null) decls.width = `${fmt(widths[cls])}px`
              if (heights[cls] != null) decls.height = `${fmt(heights[cls])}px`
              if (!Object.keys(decls).length) continue
              const next = upsertCssDecls(keyVue, cls, decls)
              if (next !== keyVue) sizeCount++
              keyVue = next
            }
            const keylineTops = body.keylineTops || {}
            const keylineLefts = body.keylineLefts || {}
            for (const cls of new Set([...Object.keys(keylineTops), ...Object.keys(keylineLefts)])) {
              if (!KEYLINE_CLASS_RE.test(cls)) continue
              const decls: Record<string, string> = {}
              if (keylineTops[cls] != null) decls.top = `${fmt(keylineTops[cls])}px`
              if (keylineLefts[cls] != null) decls.left = `${fmt(keylineLefts[cls])}px`
              if (!Object.keys(decls).length) continue
              const next = upsertCssDecls(keyVue, cls, decls)
              if (next !== keyVue) sizeCount++
              keyVue = next
            }
            if (keyVue !== keyVueOriginal) await writeFile(vueAbs, keyVue, 'utf-8')
          }

          res.statusCode = 200
          res.setHeader('Content-Type', 'application/json')
          res.end(
            JSON.stringify({
              ok: true,
              keys: keys.length,
              widths: sizeCount,
              storePath: body.storePath,
              matrixName,
              pluginVersion: RK_ALIGN_PLUGIN_VERSION,
            })
          )
        } catch (error) {
          server.config.logger.error(`[rk-align] 写入失败: ${String(error)}`)
          res.statusCode = 500
          res.setHeader('Content-Type', 'application/json')
          res.end(JSON.stringify({ ok: false, error: String(error) }))
        }
      })
    },
  }
}

