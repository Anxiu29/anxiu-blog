import { createApp } from 'vue'
import { getActivePinia } from 'pinia'
import AlignTool from './keyAlignTool.vue'

/** 独立挂载对齐工具：不改 App.vue，由 Vite 插件在 dev 入口末尾调用 */
export function mountAlignTool() {
  if (typeof document === 'undefined') return
  if (document.getElementById('rk-align-root')) return

  const el = document.createElement('div')
  el.id = 'rk-align-root'
  document.body.appendChild(el)

  const app = createApp(AlignTool)
  const pinia = getActivePinia()
  if (pinia) app.use(pinia)
  app.mount(el)
}

