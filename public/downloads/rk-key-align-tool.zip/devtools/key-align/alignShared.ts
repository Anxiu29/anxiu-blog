/** 对齐工具 / 写回插件共用：按键尺寸 class 命名 */

/** 最多两位小数，去掉二进制浮点尾巴（如 -2.9000000000000004） */
export const round2 = (v: unknown): number => {
  const n = Number(v)
  if (!Number.isFinite(n)) return 0
  return Number(n.toFixed(2))
}

/** 真正控制宽高的 class（不含 key_left_1 / key_small 等） */
export const SIZE_CLASS_RE =
  /^key_(?:mute|macro|esc|nav|backspace|tab|slash|cap|enter|l_shift|r_shift|l_ctrl|r_ctrl|ctrl|fn|space|r_alt|num_plus|num_enter|num_0|i_\d+)(?:_[a-z0-9]+)?$/i

export const KEYLINE_CLASS_RE = /^keyline_\d+(?:_[a-z0-9]+)?$/i

/** 行/键上用来区分语言的 class，键位序号相同时仍能分开两份矩阵 */
export const styleMarks = (style?: string): string =>
  (style || '')
    .split(/\s+/)
    .filter((c) => KEYLINE_CLASS_RE.test(c) || SIZE_CLASS_RE.test(c))
    .sort()
    .join('+')

export const layoutToken = (index: number, position: number, style?: string): string =>
  `${index}:${round2(position)}:${styleMarks(style)}`

/** 去掉连接方式和型号里的分隔符。rk r104pro es wire → rkr104proes */
export const normKbName = (s: string): string =>
  s
    .toLowerCase()
    .replace(/\b(wire|keyboard|dongle)\b/g, '')
    .replace(/[\s_-]+/g, '')

/** 设备名多带一个 rk 前缀时，仍能对上 switch 里的 R104pro ES */
export const nameVariants = (s: string): string[] => {
  const n = normKbName(s)
  if (!n) return []
  const out = [n]
  if (n.startsWith('rk') && n.length > 2) out.push(n.slice(2))
  return out
}

export const parseSwitchMap = (src: string): Map<string, string> => {
  const pending: string[] = []
  const map = new Map<string, string>()
  const re = /case\s+['"]([^'"]+)['"]\s*:|tmp\s*=\s*(keyMatrix_\w+)/g
  let m: RegExpExecArray | null
  while ((m = re.exec(src))) {
    if (m[1]) pending.push(m[1])
    else if (m[2]) {
      for (const n of pending) map.set(n, m[2])
      pending.length = 0
    }
  }
  return map
}

/** 名单按优先级排列。第一个能对上 switch 的名字生效，后面的名字不能把它盖掉。 */
export const matrixNameForKeyboard = (src: string, names?: string[]): string | null => {
  const list = (names || []).map((n) => n.trim()).filter(Boolean)
  if (!list.length) return null
  const map = parseSwitchMap(src)
  if (!map.size) return null

  const matchOne = (raw: string) => {
    const wants = nameVariants(raw)
    if (!wants.length) return null
    let bestMatrix: string | null = null
    let bestScore = 0
    for (const [caseName, matrix] of map) {
      const haves = nameVariants(caseName)
      for (const want of wants) {
        for (const have of haves) {
          if (!want || !have) continue
          let score = 0
          if (want === have) score = 1000 + have.length
          else if (want.startsWith(have)) score = 100 + have.length
          else if (have.startsWith(want) && want.length >= 4) score = 50 + want.length
          if (score > bestScore) {
            bestScore = score
            bestMatrix = matrix
          }
        }
      }
    }
    return bestMatrix
  }

  for (const raw of list) {
    const hit = matchOne(raw)
    if (hit) return hit
  }
  return null
}

export const fingerprintMatrix = (
  body: string,
  getIndex: (l: number, c: number) => number,
): string => {
  const seq: string[] = []
  for (const line of body.split(/\r?\n/)) {
    if (line.trim().startsWith('//')) continue
    const style = line.match(/style:\s*['"]([^'"]*)['"]/)?.[1]
    const indexed = line.match(/index:\s*getIndex\((\d+),\s*(\d+)\)/)
    const position = line.match(/position:\s*(-?[\d.]+)/)
    if (indexed && position) {
      seq.push(layoutToken(getIndex(Number(indexed[1]), Number(indexed[2])), Number(position[1]), style))
      continue
    }
    const raw = line.match(/index:\s*(\d+)\b/)
    if (raw && position) {
      seq.push(layoutToken(Number(raw[1]), Number(position[1]), style))
      continue
    }
    const lineMark = styleMarks(style)
    if (lineMark && KEYLINE_CLASS_RE.test(lineMark.split('+')[0] || '')) {
      seq.push(`L:${lineMark}`)
    }
  }
  return seq.join(',')
}

/** 去掉早期自动补的尺寸 class，避免和正式 key_xxx 叠在一起 */
export const stripLegacySizeClasses = (style: string): string => {
  const parts = style.split(/\s+/).filter(Boolean)
  const hasReal = parts.some((c) => SIZE_CLASS_RE.test(c) && !/^key_i_\d+$/i.test(c))
  return parts
    .filter((c) => {
      if (/^key_[wh]_\d+$/i.test(c)) return false
      if (hasReal && /^key_i_\d+$/i.test(c)) return false
      return true
    })
    .join(' ')
}

