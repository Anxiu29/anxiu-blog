# RK 键位对齐工具（项目内开发工具）

这四个文件从用户提供的组合源码按文件边界拆分，未修改实现逻辑。
原文另提供 rk-key-align-original.txt。插件/面板版本为 8，不代表通用软件发布版本。

## 目录

把 devtools/key-align/ 目录放到 RK 项目根目录下：

- mount.ts：独立挂载 Vue 面板并复用活动 Pinia。
- vitePlugin.ts：仅 serve 时注入入口，提供 /__rk_align_write 写回接口。
- alignShared.ts：布局识别、尺寸 class 与数值处理。
- keyAlignTool.vue：基于当前页面 .keybox 与 keyinfo_* store 的对齐面板。

vitePlugin.ts 用 ../.. 推导项目根目录，保留上述目录层级。

## 接入

合并到现有 vite.config.ts（不要覆盖项目已有插件配置）：

    import { rkAlignWritePlugin } from './devtools/key-align/vitePlugin'

    // 在现有 plugins 数组中追加：
    rkAlignWritePlugin()

如项目已有“文件存在才加载”的可选工具逻辑，应接入那套逻辑。
完全重启 npm run dev 后，进入具体键盘改键页面，点击“对齐工具”。
无需手动改 App.vue 或重复调用 mountAlignTool。

## 依赖与适用范围

需要 Vue 3、Pinia、Vite，以及原项目的 @/device/enum（ProtocolType.JuPeng）、
keyinfo_* Pinia store、state.keyMatrix、.keybox 按键 DOM 和已有背景图。
写回目标为 src/stores/**/keyStore.ts 与 src/components/**/key.vue。
本包不包含 RK 完整项目、键盘背景图、固件或协议实现。
它不是油猴脚本，也不是脱离原工程即可运行的在线编辑器。

## 操作

- 单击选中；Ctrl/Command 多选；Shift 同行连选。
- 左右调整 offset，上下调整 offsetY；WASD 调整整行。
- [ / ] 调整宽度；; / ' 调整高度；B 黑字、V 白字；Esc 取消选择。
- 支持 1、2、5 步进及数值输入，单键/共用按键尺寸和面板拖动/缩放。
- 半透明紫色按键覆盖在原有底图上，便于观察边界。

“写入代码”会修改本地源码：offset/offsetY/style 写入 keyStore.ts，
尺寸及整行 top/left 等 CSS 写入 key.vue。写入前保存现有改动，写入后检查 diff。
插件包含路径范围、版本与布局匹配检查，但不保证适配其他工程或任意布局。
本次仅验证源码拆分、打包与展示页面，未在 RK 项目执行写回操作。
