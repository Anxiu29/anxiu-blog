雾镇夜行 · 离线试玩包

解压后，用支持 WebGL 2 的桌面 Chrome 或 Edge 打开“雾镇夜行.html”。
游戏资源已内嵌，无需联网下载运行资源。桌面键鼠游玩优先。

WASD 移动，鼠标环顾，Shift 奔跑，C 蹲行，F 手电，E 交互。
Q 投石诱敌，R 强光逼退，M 手记/地图，Esc 暂停。
如感到卡顿，可在标题页或暂停菜单切换画质。

项目介绍：https://anxiu-blog.vercel.app/projects/fog-town/
第三方许可见 THIRD_PARTY_LICENSES.txt。
扫描材质来源见 assets/slice/license/scanned-materials-manifest.json。
这是单关卡原型；性能和原生鼠标锁定需结合设备实际体验。
